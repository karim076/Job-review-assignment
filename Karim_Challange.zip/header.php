<div class="wrapper">
	<img src="img/main/button-meerinfo.png" alt="">
	<div class="row d-flex justify-content-between">
		<h1 class="degs">Hoogbegaafde topmodellen</h1>
	</div>
</div>
<section>
	<nav class="firstBackground d-flex align-items-center">
		<a href="#" class="links">Home</a>
		<div class="d-flex flex-column test">
				<a href="" class="links opens-dropdown" id="special-dropdown">Hoogbegaafd</a>
				<div class="dropdown position-relative">
					<div class="padding">
						<div class="colum d-flex flex-column">
							<a href="#" class="hover">Marketeer</a>
							<a href="#" class="hover">Programmeur</a>
							<a href="#" class="hover">financieel</a>
							<a href="#" class="hover">bedrijfskunde</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<a href="#" class="links">Topmodel</a>
		<a href="#" class="links">over ons</a>
		<a href="#" class="links">contact & route</a>
	</nav>
</section>
<div class="toggle">
	<div class="mobile-container">

		<!-- Top Navigation Menu -->
		<div class="topnav">
			<a href="#home" class="active">Top modellen</a>
		<div id="myLinks" class="h hover">
			<a href="#">Home</a>
			<a href="#">Hoogbegaafd</a>
			<a href="#">Topmodel</a>
			<a href="#">Over Ons</a>
			<a href="#">Contact & route</a>
		</div>
		<a href="javascript:void(0);" class="icon toggler-example purple darken-3" onclick="myFunction()"><img src="img/icon/hamburger.png" alt="burger menu"></a>
		<i class="fa fa-bars"></i>
		</a>
	</div>
	<!-- End smartphone / tablet look -->
	</div>

<script>
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>
</div>
    <!-- Links -->
<!-- <nav class="">
	<div class="container-fluid float-end p-0 ">
		<div class="container float-end p-0">
			<img class="img-fluid position-relative d-block zindexs float-end indexs" alt="Responsive image" src="img/header/menubalk.png">
			<div class="firstBackground">
				<a href="" class="me-6 h2">Home</a>
				<a href="" class="me-6 h2 dropdown">Hoogbegaafd</a>
				<div class="dropdowns mb-1 d-flex flex-column">
					<div class="imgDropdown ">
						<img src="img/header/dropdown.png" class="" alt="Responsive image">
						<div class="list ">
							<a href="mr">solution</a>
							<a href="mr">solution</a>
							<a href="mr">solution</a>
							<a href="">solution</a>
						</div>
					</div>
				</div>
				<a href="" class="me-6 h2">Topmodel</a>
				<a href="" class="me-6 h2">over ons</a>
				<a href="" class="me-6 h2">contact & route</a>
			</div>
		</div>
	</div> 
	<img class="img-fluid d-block zindexs" alt="Responsive image" src="img/header/menubalk.png">
	<div class="overflowText d-block zindex">
		<a href="">Home</a>
		<a href="">Hoogbegaafd</a>
		<a href="">Topmodel</a>
		<a href="">over ons</a>
		<a href="">contact & route</a>
		<a href=""></a>
	</div>
</nav> -->